MULLET FORCE candidate: three co-op enemies and immediate punch jump cancel.
Source: 0f5daa1b82de22fa2050d49673a8ddb4a2462d81
Baseline: f05bc55d357f258fc924d41f5bdd58050a317e60
Keep BIN/CUE together; open the CUE. Hardware/playtesting approval pending.
