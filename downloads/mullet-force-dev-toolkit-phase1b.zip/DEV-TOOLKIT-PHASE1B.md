# Mullet Force developer toolkit Phase 1B

The owner-approved THE ONE tag `the-one-dev-toolkit-phase1a-definitive`
resolves to `d0ab737f472583f482a5c7e8694a7ddc31d2f2e8`. The previous
`the-one-bruce-overhaul-definitive` tag still resolves to
`55e9889588d47e2b7374e43f852da1779a6089cd`.

Source branch `feature/dev-toolkit-phase1b` builds this playtest from
`d8eb21c9ada9ce1c30ea5a65cd8f4034c9a45329` with
`MF_DEV_MODE=1 bash tools/build-source-complete.sh`. Keep the BIN alongside
the CUE and open the CUE. Run `sha256sum -c SHA256SUMS.txt` to verify the
extracted archive.

## Controls and behavior

- P1 Start pauses in Level 1. Up/Down moves the menu cursor and A confirms.
  B goes back or resumes from the top menu. Start also resumes from the
  menu. X retains the approved direct Level 2 shortcut in the pause menu.
- God Mode applies to both players and survives Level 1 section jumps and
  restarts. It prevents HP loss while retaining hit reactions, knockback,
  hit registration and SFX. It starts off and clears on Level 2 entry.
- Refill Health restores every living active player to full HP while the
  game stays paused. Defeated players keep their normal recovery.
- Free Camera uses Left/Right. Hold A for faster movement. B or Start
  returns to the paused menu. Use a separate resume input to continue.
  The displayed X is the camera origin, from 0 through 2880. The final
  viewport includes the 3200-pixel panorama endpoint. The normal HUD and
  pause panel are hidden during inspection.
- Phase 1A section selection, restart and Level 2 skip remain available.
  Level 2 continues to use its existing pause behavior.

## Validation

Both pinned native builds and both `make check` runs passed. The host suite
includes co-op vehicle hits, health refill, and God Mode persistence and
cold reset. A focused host fixture used the Corporate Punk and Ricky
attack paths and verified hit latches, knockback, hurt events and HP with
both settings. The enabled Yabause HLE replay covered vehicle damage
and God Mode, late P2 join, paused refill, section jump and restart,
Bruce combat, multiple full camera sweeps and pause-only Level 2 entry.
The replay compared the entire gameplay state before and after each
free-camera session, including camera, floors and encounter state.
Sprite-bank generation and mapped sound-bank ownership remained stable
during inspection. The disabled build booted, paused and entered Level 2
through its existing X shortcut. Full BIOS and physical Saturn testing
remain open.

## Memory and disc layout

| Resource | Approved Phase 1A | Phase 1B dev |
| --- | ---: | ---: |
| VDP1 street texture residency | 386,432 B | 386,432 B |
| VDP1 Bruce texture residency | 401,600 B | 401,600 B |
| Level 1 SCSP mapped upper bound | 517,300 B | 517,300 B |
| Level 1 SCSP headroom | 6,988 B | 6,988 B |
| VDP2 reserved | 434,176 B | 434,176 B |
| Native executable | 281,536 B | 282,736 B |
| Linked BSS span | 445,540 B | 445,540 B |

The renderer uses a separate view coordinate and the existing background
tile cache. Gameplay remains paused and no snapshot buffer is used.
There are no added audio or sprite allocations. SCSP figures are mapped
extents. Live voice occupancy and heap fragmentation were not profiled.

All 435 non-executable disc files match Phase 1A byte for byte in both
builds. STAGE.SEQ and STAGE.TON remain at zero-based GFS root records
254 and 255. The Level 2 and Ricky directories retain their original
positions.
