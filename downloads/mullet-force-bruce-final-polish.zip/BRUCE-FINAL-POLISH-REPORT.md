# Mullet Force Bruce final polish

The Saturn playtest is built from `6816401314dd0fd7a950fc10239b06873a5c5315` on `feature/bruce-final-polish`, based on the approved custom-SFX candidate `70b17960780a40cf9a8a23476b5e70eb307017df`. The official tag `the-one-performance-phase2-definitive` still resolves to `758cca4bcb314608d0f5eac26b28b6be5e14769a`.

## Bruce jumps and sound

| Jump | Previous peak | New peak | Airborne interval before → after | WOOPAH event to landing |
|---|---:|---:|---:|---:|
| Entrance | 62 px | 78 px | 48 → 48 ticks | 48 gameplay ticks |
| Regular slam | 44 px | 55 px | 32 → 32 ticks | 18-tick windup + 32-tick arc |
| Anti-stunlock counter | 48 px | 60 px | 26 → 26 ticks | 20-tick windup + 26-tick arc |

The combat increases are exactly 25%. The entrance rounds the 77.5 px target to 78 px. The parabolas use larger height constants with the original horizontal and depth interpolation. Bruce retains his 75 HP and the existing AI, windups, damage, landing recovery, collision rules and sprite frames. The existing raised-arms pose covers each combat windup. The replay camera and pose geometry put the top of the entrance sprite at least 49 px below the top of the display, and the top of the observed counter arcs at least 34 px below it. The existing shadow still draws at the road position.

The entrance jump event previously drove the boss music handoff alone. It now also requests the existing WOOPAH sample through Bruce’s voice port. The native fixture verifies one entrance event and one landing event. The music handoff uses the same event and port as before.

WOOPAH retains its approximately 1.214-second duration and pitch. At 60 Hz, the nominal cue-to-contact delays are 0.80 s for the entrance, 0.83 s for the slam and 0.77 s for the counter. The engine sends the explosion request on the positive-height to zero-height contact tick. The existing explosion plays through the world FX port, while WOOPAH and Bruce’s protected death voice have separate transport. A bat-interrupted jump sends no explosion event.

In the solo and co-op Yabause recordings, the entrance WOOPAH sample became active one emulated field after the entrance event. The explosion sample became active on the landing field, 47 fields after WOOPAH became active. Counter landings occurred 49–55 fields after WOOPAH became active, depending on hit-stop and audio dispatch. Both samples were active together on all 21 observed landings. The ordinary slam uses the same explosion dispatch and passed the native same-tick landing fixture. These controller replays produced counter jumps during combat.

## Buck and Chuck

Flat, unobstructed horizontal distance is measured from the takeoff input through the ground-contact tick for each player.

| Jump | Speed | Distance | Peak | Duration |
|---|---:|---:|---:|---:|
| Walking | 390/256 px per tick | 63.98 px | 63.16 px | 42 ticks |
| Running | 663/256 px per tick | 108.77 px | 63.16 px | 42 ticks |

A jump from an established run uses the existing 1.7× horizontal speed. Neutral input stops horizontal movement, reversal responds immediately, and depth movement keeps its existing rate. Height, gravity, animation and standing-jump movement retain their existing values. The added movement state is per player and clears at landing and on damage. Tests exercised solo Buck, independent Chuck running alongside walking Buck, simultaneous co-op, real double-tap input, a jump buffered through hit-stop, reversal, neutral, air kicks and repeated B during flight. A downhill vehicle fixture ran the same route grounded and airborne. The grounded player took the vehicle hit and the jumping player cleared it.

## Build, memory and replay evidence

- Native SH-2 BIN/CUE build, `make check` and `make test` passed. The staging comparison matched all 435 non-executable disc files byte for byte against the approved custom-SFX build. Phase 2 streaming assets and code are unchanged.
- The largest mapped SCSP footprint remains 517,300 of 524,288 B, leaving 6,988 B. During the vehicle phase, 508,836 B are occupied, leaving 15,452 B physically unoccupied. The explosion and WOOPAH reuse existing samples and banks. High work RAM links through `0x060b59c4`, leaving 42,556 B below the SGL sort-work boundary.
- Yabause ran two 9,000-field controller replays using HLE BIOS. Both showed two missed callback opportunities before the Bruce bank transfer, 53 during the entrance transfer interval, and zero during steady combat through defeat. The comparable previous build recorded the same counts. No audio bank fault was observed. The SCSP trace registered standard POOWAH playback on the street and zero active POOWAH slots during Bruce’s encounter.
- Co-op defeat occurred at field 6425 and solo defeat at field 7573. After each defeat the existing Saturn X debug shortcut loaded Level 2 and the emulator drew it at fields 6667 and 7815 respectively. This checks the existing loader and rendering handoff through the shortcut. Physical Saturn audio, visuals, pacing and play feel are pending.

Open `mullet-force.cue` with the BIN beside it. Press P1 Y for the MISS overlay. Listen for one WOOPAH as Bruce enters and one explosion as he touches down. Try both running jumps and walking jumps on the downhill stretch, and try dodging a combat counter before jumping in to punish the recovery.
