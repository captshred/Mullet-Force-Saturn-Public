# Mullet Force developer toolkit Phase 1A

- Source branch `feature/dev-toolkit-phase1a`
- Source commit `d0ab737f472583f482a5c7e8694a7ddc31d2f2e8`
- Approved baseline `55e9889588d47e2b7374e43f852da1779a6089cd` (`the-one-bruce-overhaul-definitive`)
- Native playtest profile `MF_DEV_MODE=1 bash tools/build-source-complete.sh`
- Compiler/SDK SH GCC 8.2.0 and Jo Engine `556d081146211b6a1cfa6591d70f9487d406758b`

Keep the BIN and CUE together and open the CUE. Verify the extracted files
with `sha256sum -c SHA256SUMS.txt`. The disc uses MODE1/2048.

## Controls

P1 Start opens the pause menu and resumes from either menu. D-pad Up and
Down move the cursor. A confirms. B returns from the section list or
resumes from the main pause menu. P1 or P2 X still invokes the existing
pause-only Level 2 shortcut. Start+A+B+C remains the global reset chord.

Section Select opens at the current section. Select a destination or choose
Restart Section to rebuild the current section and resume automatically.
Both paths use the same initializer.

## Level 1 sections

| Destination | P1 world X | Entry state |
| --- | ---: | --- |
| Opening Street | 100 | Opening props and normal street spawner |
| ION ARCADE | 450 | Arcade exterior with normal street spawns |
| Intersection | 1570 | Intersection frontage with normal street spawns |
| Downhill Street | 1950 | Existing road grade before the vehicle trigger |
| Vehicle Ambush | 2240 | Native warning and three-pass sequence from the start |
| Parking Garage | 2640 | Garage approach, vehicle sequence already completed |
| Bruce Mini-Boss | 2758 | Fresh boss and full entrance using the existing sprite and sound bank handoff |
| MEGA ARCADE Apron | 3095 | Outdoor doorway with Bruce defeated and his encounter music selected |

Each destination restores the currently active Buck and Chuck to full health
with their standard moves and equipment, using ground-relative lanes and the
existing camera bounds and progression floors. It clears the previous run's
actors, combat effects, timers, and encounter state. The normal street spawner
starts with its initial delay where enabled. The stage still ends at the apron.
Bruce remains the restart destination after defeat until players enter another
defined section.

## Validation and memory

Native builds and disc checks passed with developer mode enabled and disabled.
Host regressions cover the shared initializer, both player counts, repeat
initialization, the vehicle warning, the Bruce entrance event and defeat state.
The Yabause controller replay uses HLE BIOS and passive reads of native state.
It covers cold play, pause and cancel, every destination, backward selections,
co-op, vehicle restart, Bruce restarts before and after a controller-driven
defeat, and Level 2 handoff. The audio replay observes the Bruce entrance cue,
battle music state and vehicle drive cue plus non-silent PCM. It also confirms
that the vehicle latch survives pause and resume within a pass.

All 435 non-executable files in the disc image match the approved pause-only
playtest byte for byte. The 265-record root still places STAGE.SEQ and STAGE.TON
at zero-based records 254 and 255. ALEVEL2 is at record 42. Bruce resources
remain under RICKY. No art, audio or new disc-root resources were added.

| Resource | At cold street entry | Across repeated section changes |
| --- | ---: | ---: |
| VDP1 resident texture bytes | 386,432 | 386,432 street / 401,600 Bruce |
| VDP1 resident peak bytes | 386,432 | 401,600, with no increase on later swaps |
| Level 1 SCSP mapped upper bound | 517,300 B | 517,300 B (6,988 B free) |
| Level 2 SCSP mapped upper bound | 506,660 B | 506,660 B |
| VDP2 reserved | 434,176 B | 434,176 B |

WRAM comparison from the native link map shows 32 additional bytes of BSS
and 2,992 additional bytes in the executable with developer mode enabled.
SCSP figures describe address extents. The replay observes tone-bank ownership
as it switches and does not profile individual voice occupancy or heap
fragmentation. Repeated swaps reused the existing texture suffix allocation.

The global reset test passes using the production chord and dispatch functions
with the Saturn reset call mocked. The HLE core did not complete the system
reboot from the controller chord. Full BIOS and physical Saturn behavior have
not been verified. The sandbox run uses controller replays and audio state
checks without a listening review.
