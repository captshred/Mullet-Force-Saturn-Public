# Mullet Force pause-only level skip

This Saturn playtest is built from `55e9889588d47e2b7374e43f852da1779a6089cd` on `feature/pause-only-level-skip`. Its parent is the approved Bruce final-polish build `6816401314dd0fd7a950fc10239b06873a5c5315`. THE ONE remains `758cca4bcb314608d0f5eac26b28b6be5e14769a`.

P1 START still pauses and resumes. Either connected controller can press X once the game is paused. P2 START retains its join behavior. X edges received during active play are discarded. Holding X into pause or pressing X and START together leaves the game paused in Level 1. Release X and press it again to request the Level 2 handoff. The shortcut consumes the edge and clears pause, then the existing audio and graphics handoff starts Level 2 with its normal loading and title sequence.

## Validation

- Native Saturn build, `make check`, and `make test` passed. The disc comparison against approved Bruce final polish found 436 files in both images. Only the Saturn executable differed.
- The host regression exercises title and active X, P1 START pause and resume, P2 join, held X, simultaneous START+X, fresh paused X from either port, edge consumption and the configuration that compiles the shortcut out.
- Solo Yabause exercised a P1 skip from the street and repeated the P1 skip after defeating Bruce. Co-op Yabause took the game through Bruce, exercised active X in street gameplay and during the boss fight, and skipped with P2 after P1 paused. Both runs exercised START resume, X held into pause, simultaneous START+X, and X held across the unpaused Level 2 handoff. Level 2 produced gameplay draw commands.
- The START+A+B+C poll and dispatch passed a host test of the actual reset code with mocked Saturn calls on both ports. It also covered clearing pending input and retrying a rejected reset request. This Yabause core leaves the Saturn SYSRES command unimplemented. Physical restart and overall hardware verification are pending.

Keep the BIN and CUE together and open `mullet-force.cue`.
