# Level 2 native music — Wristbreaker

Based on the user-approved `506d5f1762d1f70bbf8975b36c616c0fa5f54472`
(`fix/level2-turret-load-e008`), on `feature/level2-native-music`.

The retained Guitar Pro source is `assets/music/Wristbreaker.gp`. alphaTab 1.9.0
reads its actual zipped GPIF representation. `assets/music/level2.mid` is a
three-track Standard MIDI File reference; `level2-articulations.json` retains
note IDs, track/measure/beat/tick positions, original instrument assignments,
palm muting, slides, vibrato, hammer/pull links, ties, bends and available
harmonic/dead-note/accent/tremolo fields, plus the exact performance callbacks.
No score text or metadata is executed.

## Composition and accuracy

- 141 written and performed measures, all 4/4; 206 BPM, no tempo changes/repeats.
- Whole-score duration: 541,440 ticks at 960 PPQN, 164.271768 seconds.
- Source track names: Distortion Guitar, Distortion Guitar, Electric Bass.
  Roles: Rhythm Guitar 1, Rhythm Guitar 2, Bass Guitar. Source GM programs 30,
  30 and 33 are retained in the reference MIDI and source metadata.
- Notated notes: 1,920 / 1,920 / 1,064. Performed notes: 1,669 / 1,670 / 1,064.
  All 4,904 source notes are accounted for: 501 are tied or legato-slide
  continuations of an originating gate; 4,403 start sounding notes.
- Native SEQ pitches, note durations, velocities, tempo and synchronization are
  checked against the reference MIDI. An independent GPIF traversal expands
  the reused bar/voice/beat/note definitions and checks every notated pitch in
  every measure/track against the parsed score. No passages are dropped.
- Nine maximum held music notes; 18 with a conservative 100 ms release window.
- 15,031 source per-note pitch-wheel callbacks retained in JSON; 14,891 native
  bend events after coalescing repeated same-tick points, dropping points
  exactly at note-off, and adding explicit loop reset bends.
- 104 continuation curve points are rebased from their legato destination key
  to the still-held originating MIDI key, preserving the intended slide pitch.
- Bends use the source 16-semitone wheel range; native SEQ rounds 14-bit MIDI
  wheels to 7 bits. Maximum error for this composition: 11.9140625 cents.
- No explicit authored bend curves, harmonics, dead notes, accents or tremolo
  picking occur in this score. Present note effects include 1,348 palm mutes,
  548 slide-outs, 28 slide-ins, 24 vibrato marks and 110 hammer/pull origins.
  Effects are retained without inventing additional musical parts.

Ordinary MIDI/SEQ cannot reproduce Guitar Pro's RSE guitar timbre or all
articulation semantics. Gates and generated pitch curves follow alphaTab's
interpretation; the original source and richer note metadata remain available
for future upgrades. No new articulation playback engine is introduced.
PCM rhythm guitar (program 0) and bass (program 2) are reused from the approved
Level 1 bank. Its existing unused lead/drum PCM entries remain in the copied
bank but receive **no notes**. No FM, streaming audio, drum or lead parts are added.

## Runtime and isolation

`WMUSIC.SEQ`, `WMUSIC.TON`, and `WMUSIC.MAP` are staged beside the unchanged
26 Level 2 payloads in `/ALEVEL2`. Level 1's source, STAGE/FX payloads, map,
configuration and playback remain unchanged. Entering Level 2 already halts
the 68000 and clears sound RAM; that existing transition prevents simultaneous
Level 1 and Level 2 playback. The proven padded MAP initializer, dry DSP arena,
DMA wait and consumed-command readiness handshake are retained and extended.

The pinned driver has only eight sequence controls, all already assigned to
Level 2 SFX. Music shares control 0 while reserving channel 0 exclusively for
its original flame; music uses channels 1..8 and 10..15, with tone bank 1.
Original SFX controls, channels, bank 0, gains, PCM, envelopes, scheduler and
weapon events are preserved. Flame channel 0 is reconfigured after the single
music start command is consumed and before gameplay begins. Music changes only
its own channel programs/bends/controllers at the loop boundary. The converter's
new opt-in `--used-channels` prevents its historical all-channel bank setup from
touching the flame. Existing default converter behavior is retained.

Unbent chords share a track channel. Notes with bends, or overlapping identical
keys, receive an isolated channel with a 50 ms reuse guard; the conversion fails
on exhaustion instead of stealing, truncating or colliding bends. The native
sequence starts at the end of the title/readiness gate, loops the entire score,
and pauses/resumes with the stage. The authored silent opening measure is
retained at each loop; it is not an added gap or a shortened composition.

## Sound RAM and voices

| Region | Start | Bytes | End (exclusive) |
|---|---:|---:|---:|
| Existing driver/work/DSP/PCM reservations | 0 | 148,864 | 148,864 |
| Original Level 2 SFX SEQ | 148,864 | 84 | 148,948 |
| Original Level 2 SFX TON | 148,948 | 158,312 | 307,260 |
| Level 2 music SEQ | 307,260 | 69,652 | 376,912 |
| Level 2 music TON | 376,912 | 70,676 | 447,588 |
| Free sound RAM | 447,588 | 76,700 | 524,288 |

The music bank contains 70,320 bytes of existing PCM payload (the remaining
356 bytes are its existing headers/tables/padding). Its only byte changes from
STAGE.TON are eight voice-header bend-range bytes, from 6 to 16 semitones.
The extended MAP is 56 bytes, with a 60-byte padded initialization buffer.
The original SFX MAP/SEQ/TON are unchanged; the extended map retains their
addresses and adds sequence/tone bank 1 above their high-water mark.

Conservative physical bound: 18 music slots with 100 ms tails + 10 SFX slots
(including flame handoff/release allowance) = 28 of 32. Four slots remain beyond
that bound. This is a static bound using the inherited SFX budget, not a claim
of measured simultaneous hardware playback or a guarantee for longer future
release envelopes. No music/SFX note is deleted to fit RAM or voices.

## Reproduce and validate

Run `bash tools/setup.sh` for the pinned SDK; use `tools/bootstrap.sh` or the
rootless `tools/setup-cloud.sh` for host prerequisites. To regenerate the score
conversion, run `npm ci --cache /workspace/work/npm-cache` in
`tools/level2-music`, then `node tools/level2-music/convert.cjs` from the repository
root, followed by `python3 tools/build-level2-music.py`.

Build with `bash tools/build-level2-wingsuit.sh --native`, then `make check`
and `make test`. `tools/validate-level2-music.py` verifies GPIF, MIDI, SEQ, tone
bank, RAM and approved-source preservation. Existing gameplay/renderer/SFX tests
remain active. Source-lock documents remain immutable; a separate exact
before/after music lock records the narrow integration changes.

Structural validation, native compilation and mocked SDK/driver regressions do
not establish audible playback. This environment has not performed an audible
Saturn emulator or physical hardware test. Listen through the full composition,
loop, pause/resume and simultaneous two-player weapons on a Saturn emulator and
hardware before calling the soundtrack audibly approved.
