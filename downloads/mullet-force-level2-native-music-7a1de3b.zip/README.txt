Mullet Force Saturn — Level 2 Wristbreaker native music

Source commit: 7a1de3bda065a3397de764ae5469793405f2aef4
Source branch: feature/level2-native-music (private workspace authoring)
Approved gameplay base: 506d5f1762d1f70bbf8975b36c616c0fa5f54472

Extract all files together and open mullet-force.cue.
Track format: MODE1/2048. This is the complete two-stage build.
The existing development X skip to Level 2 remains enabled.

Native build, make check and make test passed.
No audible Saturn emulator or physical-hardware test was performed.
The first authored measure is silent; Level 2 music then plays and loops
the complete 141-measure composition. Pause/resume follows the stage.

This public ZIP contains runtime BIN/CUE and reports only. Original GP,
source MIDI, articulation JSON and the authoring source bundle remain private.
See level2-native-music.md for accuracy, memory, voice and playback details.
