# Bruce · Phase 2B three-frame walk

The approved idle is retained at `0c56cf8bd3df9059faf7a39ed5916337b06dfd50`.
The three walk textures use its exact 254-color RGB555 palette. Each
144 × 120 right-facing production PNG has hard alpha and pivot (64, 112).
The walk sheet's black matte and labels are removed. The native silhouettes
are aligned by stance, cleaned at the edge and sampled with nearest pixels.

| Output | Source pose | Visible size | Texture and anchor | VDP1 bytes | Hold |
| --- | --- | --- | --- | ---: | ---: |
| walk_00_r.png | WALK 00 | 104 × 95 | 104 × 95 at (53, 95) | 9,888 | 200 ms |
| walk_01_r.png | WALK 01 | 106 × 96 | 112 × 96 at (53, 96) | 10,752 | 170 ms |
| walk_02_r.png | WALK 03 | 104 × 95 | 104 × 95 at (54, 95) | 9,888 | 210 ms |
| Total | 3 unique textures | | | 30,528 | 580 ms |

The walk and existing idle total 50,112 aligned texture bytes.
The walk reuses the idle palette byte for byte. There are no identical
full-frame payloads to deduplicate. Keep complete textures for this
review since the arms, knees and boots change together. Raw TGA index 0
is the transparency key and raw 255 is unused. Host checks confirm the
decoded opacity mask, dimensions, anchors, and aligned bytes against
the PNGs and manifest. In-game stride timing and foot contact can be
evaluated once the animation has been staged in a later phase.

The authoring sheet stays private. To reproduce from an approved local
copy, use `python tools/prepare-bruce-walk.py brucewalk.png --output assets/bruce/walk --previews docs/bruce-walk-review`.
