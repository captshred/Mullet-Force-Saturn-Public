# Bruce · Phase 2A idle sprite review

Prepared from the approved 2172 × 724 three-pose RGBA sheet. Source SHA-256
is `317b711fe106aceecf87d5b79219c69c2d1b49be7d45df9c1365fda479e9176b`.
The source master stays private. The production poses use nearest-pixel
sampling at the Phase 1 stocky proportions, hard alpha, isolated edge-pixel
cleanup, and a common boot strip so the planted feet do not shift. The
shoulders, fists, head and knees retain the pose changes from the source.

| Pose | Visible width × height | Runtime texture | Runtime anchor | VDP1 bytes |
| --- | --- | --- | --- | ---: |
| 00 | 104 × 95 | 104 × 95 | (53, 95) | 9,888 |
| 02 | 103 × 93 | 104 × 93 | (54, 93) | 9,696 |
| **Total** | | **2 indexed textures** | | **19,584** |

The approved loop alternates neutral pose 00 and lowered pose 02, with
adjustable 360 ms holds. Both 144 × 120 PNGs and their indexed TGAs are
byte-identical to the initial review. They share pivot (64, 112) and the
original 254-color RGB555 palette. Removing the upward pose saves 10,880
VDP1 texture bytes. Host checks verified the two decoded transparency
masks, anchors, palette bytes and aligned allocations. These are offline
byte counts. The sprites have yet to be loaded by the Saturn runtime.

Refresh previews from the approved textures and manifest with:

```sh
python tools/export-bruce-idle.py --review-existing assets/bruce/idle --output docs/bruce-idle-review
```

- [Contact sheet](contact-sheet-1x.png)
- [Buck, Chuck and Bruce at 1×](buck-chuck-bruce-1x.png)
- [Animated PNG](idle-preview.png)
- [Production manifest](../../assets/bruce/idle/manifest.json)
