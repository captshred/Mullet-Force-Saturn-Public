# Bruce · Phase 2A idle sprite review

Prepared from the approved 2172 × 724 three-pose RGBA sheet. Source SHA-256
is `317b711fe106aceecf87d5b79219c69c2d1b49be7d45df9c1365fda479e9176b`.
The source master stays private. The production poses use nearest-pixel
sampling at the Phase 1 stocky proportions, hard alpha, isolated edge-pixel
cleanup, and a common boot strip so the planted feet do not shift. The
shoulders, fists, head and knees retain the pose changes from the source.

| Pose | Visible width × height | Runtime texture | Runtime anchor | VDP1 bytes |
| --- | --- | --- | --- | ---: |
| 00 | 104 × 95 | 104 × 95 | (53, 95) | 9,888 |
| 01 | 105 × 97 | 112 × 97 | (53, 97) | 10,880 |
| 02 | 103 × 93 | 104 × 93 | (54, 93) | 9,696 |
| **Total** | | **3 indexed textures** | | **30,464** |

The 144 × 120 authoring canvases share pivot (64, 112). All three TGAs
share one RGB555 palette with 254 opaque colors, no dithering and raw
index 0 for the Jo transparency key. Raw 255 is unused. Host checks
confirmed exact decoded opacity masks, common palette bytes, indexed TGA
round-trip, aligned texture size, identical boots and all three preview
durations. The preview loop holds 320, 240 and 320 ms.

Splitting off the shared 88 × 15 boot strip would lower this idle bank to
about 26,976 bytes with a second sprite draw per pose. Keep the three
complete textures for review. The head overlaps the collar, and the torso,
arms and knees move together. Reconsider splitting once the walking and
attack art makes the reuse opportunities clearer. These are export byte
counts. The art is not yet loaded by the Saturn runtime.

- [Contact sheet](contact-sheet-1x.png)
- [Buck, Chuck and Bruce at 1×](buck-chuck-bruce-1x.png)
- [Animated PNG](idle-preview.png)
- [Production manifest](../../assets/bruce/idle/manifest.json)
