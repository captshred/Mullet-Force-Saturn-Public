# Bruce · Phase 2E ground slam

Two new right-facing character PNGs use 144 × 120 canvases, hard alpha,
and pivot (64, 112). The raised fists fit inside the unmodified canvas.
Both impact knuckles touch the same ground row. The source sparks and
debris were removed from the character texture, with the knuckle and
rear boot contours cleaned at native size.

| Pose | Runtime texture | Anchor | Hold | Aligned VDP1 bytes |
| --- | --- | --- | ---: | ---: |
| Overhead windup | BS00.TGA, 96 × 109 | (48, 109) | 250 ms | 10,464 |
| Ground impact | BS01.TGA, 104 × 70 | (52, 70) | 133 ms | 7,296 |
| Charge 00 recovery | Existing windup and idle boot view | Existing | 133 ms | 0 |
| Neutral idle | Existing BR00.TGA | Existing | 480 ms | 0 |

The lifted Charge 01 alternative appears in the airborne study.
Its forward shoulder and trailing foot read as the start of a charge.
The selected one-shot cuts directly to impact, recovers through Charge 00
and returns to idle. Existing boots and lowers were considered for the
new poses. The raised stance places both boots wider, and the impact
tucks its legs behind the fists. Retaining each native silhouette keeps
both new frames under the combined 18,000-byte target.

The effects comparison uses two placements of the existing HIT.TGA to
illustrate how the fists could read on impact. It is a preview only and
adds zero texture bytes. Source debris and pavement cracks have no runtime
allocation, and the arena has no permanent change.

The measured incremental cost is **17,760 bytes**. Cumulative Bruce usage
is **119,808 bytes**, leaving **50,168 bytes** below the 169,976-byte
reserve-safe ceiling. Remaining Phase 1 estimates are hit reactions 13,312,
stun 3,584, knockdown 12,608, get-up 7,296 and defeat 5,120. Their **41,920-byte**
total leaves **8,248 projected bytes** for trimming or palette-independent
art changes. Retain the 49,152-byte hero reserve.

Both textures share the approved idle RGB555 palette without dithering.
The PNG masks match the decoded TGA masks, raw index 255 is unused, and
the right-facing anchors mirror as width minus anchor X. All validation
was offline. The sprites and effect study await visual approval before
any runtime staging.
