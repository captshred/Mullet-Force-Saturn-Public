MULLET FORCE — Level 1 Phase 3A: The Intersection

Runtime source: 5725578cece3072d8bee01499f7914e9e0711403
Approved baseline: 43cd82d33dd6195a036f9775f8b0e961fedbe9bb
World width 1920; camera 0..1600; checkpoints0/320/640/960/1280.
Horizontal movement only; temporary endpoint; no automatic Stage2.
Keep BIN and CUE together; open the CUE.
Hardware and gameplay approval pending.
