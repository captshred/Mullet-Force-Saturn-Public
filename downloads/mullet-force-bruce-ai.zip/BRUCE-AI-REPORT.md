# Bruce mini-boss AI playtest

Candidate source `d407bc8f004e80e620ec7b37f2e5df39aa21827f` on `feature/bruce-ai-upgrade`. The worktree starts from THE ONE, `the-one-performance-phase2-definitive` at `758cca4bcb314608d0f5eac26b28b6be5e14769a`. Hardware approval for the upgrade is pending.

## Combat behavior

- **HP increased from 60 to 75**, exactly 25%. Existing entrance initialization, damage clamping, knockdown and defeat animation remain in use.
- **Three accepted non-bat hits trigger the counter.** The shared pressure counter includes hits from both players and the flamethrower. It resets after 72 simulation ticks without another qualifying hit. Bruce can break out of grounded hurt as soon as the threshold is reached, or queue the counter until an already committed attack finishes. The existing 12-tick damage immunity between accepted hits stays in place.
- **The warning lasts 20 simulation ticks** (about 0.33 seconds at 60 Hz). Bruce uses the approved raised-arms slam sprite. On takeoff he chooses the nearest living player and fixes the landing point. The arc lasts 26 ticks, peaks at 48 pixels, and travels up to 112 horizontal pixels and 44 lane pixels within his existing arena bounds. Moving after takeoff does not change his destination.
- **Damage is on touchdown only.** The landing can deal 24 damage within an ellipse with horizontal and lane radii of 38 and 19 pixels, if the player is less than 18 pixels above the ground. Moving off that spot or jumping over the impact can prevent the hit. There is no contact damage during the arc.
- **Ordinary hits and flame still deal damage** when the hurtbox connects but cannot restart the counter or lock Bruce in repeated flinches during the 150-tick counter cooldown. A connecting bat can cancel the counter, including during the arc, and a lethal hit cancels it. Bruce remains damageable for the 24-tick landing recovery. The cooldown starts with the warning and keeps the next pressure counter from immediately retriggering.
- **Bruce closes distance and aligns faster.** Horizontal and lane pursuit are faster, the target is clamped to his existing floor, and he avoids charges with insufficient runway. Below half HP, at 37 or less, retarget checks become more frequent and the extra delay after punch, charge and slam falls from 26/32/38 ticks to 20/25/30. Existing attack warning lengths and damage stay the same.

The counter reuses Bruce's bank, raised-arms pose, airborne pose and impact pose. Playback of his entrance, existing audio events, the rest of the arena and the Phase 2 streaming code were preserved.

## Verification

The native Saturn diagnostic build, `make check` and `make test` passed. The native Bruce tests exercise the 75 HP entrance, solo jab pressure, alternating co-op pressure, continuous flame, targeting at takeoff, lateral and aerial dodge checks, bat and lethal interrupts, wall pursuit, cooldown, low-health threshold, and defeat state. All 433 non-executable ISO files matched the approved disc byte for byte. The linked high-work-RAM end moved from `0x060b4cc4` to `0x060b4f24` (608 bytes), leaving 45,276 bytes before the `0x060c0000` boundary. The boss uses 12 additional bytes of state. No VDP1, VDP2 or SCSP reservation was increased.

Separate Yabause HLE runs used scripted controllers and passive game-state reads. Both entered from normal Level 1 traversal and defeated Bruce using the existing player recoveries. The solo run used the existing dev skip 60 fields after defeat and reached sustained Level 2 gameplay. A co-op run with the same 60-field wait reached the handoff but did not start Level 2 gameplay in Yabause. A co-op retry with a 120-field wait reached the Level 2 gameplay phase with loader error 0 and rendered continuously. A separate early co-op dev skip also loaded Level 2. The approved disc also passed a late co-op dev skip at the same field on a separate traversal without the scripted fight. The failed 60-field post-fight handoff remains unresolved. The underlying Level 2 code and assets were unchanged. These runs establish that both encounters are beatable, and physical difficulty and post-fight loading remain playtest items.

| Run | Bruce entrance field | Bruce defeat field | Counter jumps | Player defeats during fight | New missed callback opportunities in fight |
|---|---:|---:|---:|---|---:|
| Solo | 4382 | 7605 | 12 | P1 3 | 0 |
| Two players | 4439 | 6542 | 8 | P1 1, P2 2 | 0 |

The standard 5,200-field Phase 2 controller replay was also repeated with the overlay hidden.

| Metric | Approved Phase 2 | Bruce upgrade |
|---|---:|---:|
| Ordinary gameplay missed opportunities | 0 | 0 |
| Bruce bank-install missed opportunities | 46 | 46 |
| Ordinary CPU median / worst callback | 2.156 / 3.964 ms | 2.157 / 3.964 ms |
| Bruce-active CPU median / worst callback, excluding bank install | 1.738 / 2.530 ms | 1.745 / 2.536 ms |

MISS measures callback opportunities. The emulator timing comparison does not measure real-Saturn raster duration or hardware missed frames. The unchanged synchronous entrance bank load still causes its existing pause.

## Saturn playtest

Keep the BIN beside the CUE and open the CUE. Press P1 Y during gameplay to toggle diagnostics. Approach the arcade lot and test the fight solo and in co-op. Try rapid jabs or sustained flame to draw the raised-arms warning, then move or jump after takeoff and punish the landing. Try a bat interrupt on a separate attempt. At low HP, watch for shorter breaks between attacks with the same warning poses. Record MISS just before the bank install, just after entrance, and after defeat to isolate the fight from the known entrance stall. To test the Level 2 load directly, wait about two seconds after defeat and use the existing Saturn X dev skip. Record any loading fault, especially in co-op.
