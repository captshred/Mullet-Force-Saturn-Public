# Bruce · Phase 2D shoulder charge

Three 144 × 120 right-facing PNGs share pivot (64, 112). The revised
third pose retains the tucked chin, leading shoulder and streaming mullet.
The source dust and speed streaks were cut from the character matte,
with additional native-pixel cleanup where they touched the silhouette.
No effect textures are included.

| Pose | Texture | Anchor | Hold in preview | Aligned bytes |
| --- | --- | --- | ---: | ---: |
| Windup | BC00.TGA, 96 × 73 | (48, 88) | 240 ms | 7,008 |
| Forward lean | BC01.TGA, 96 × 82 | (50, 82) | 150 ms | 7,872 |
| Head-down drive | BC02.TGA, 112 × 76 | (54, 76) | 420 ms | 8,512 |

The windup reuses the same aligned 104 × 15 idle boot view already specified
for the heavy punch. Its full RGBA PNG includes those boots. The lean and
drive have distinct lower silhouettes. The APNG plays once. The final hold
is for visual review and can be replaced with a gameplay-defined duration
in a later phase.

The measured unique aligned texture totals are idle 19,584, walk 30,528,
punch 28,544 and charge 23,392 bytes. Cumulative usage is 102,048 bytes,
leaving 67,928 of the 169,976-byte reserve-safe Bruce ceiling. The Phase 1
allowances for the remaining slam, reactions, stun, knockdown, recovery
and defeat consume about 67,712 bytes. That would leave just 216 bytes.
Before producing those assets, review shared slam lowers and reuse of the
knockdown silhouette in recovery and defeat. One shared 128 × 40 pose
could save 5,120 bytes if its silhouette is approved for both uses.

All textures use the exact idle palette. Host validation checked TGA
round-tripping, decoded alpha, pivot, unique aligned payload sizes and the
three preview holds. The character bank has yet to be staged or tested in
the Saturn runtime. The approved source sheet remains private.
