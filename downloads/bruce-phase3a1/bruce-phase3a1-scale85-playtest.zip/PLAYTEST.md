# Bruce Phase 3A.1

Bruce renders at 85% around his existing ground pivot. The scale is applied to both axes through Jo Engine's existing VDP1 four-point sprite draw. The disc uses the same approved 19 textures, palette and sprite bank as Phase 3A.

Play past MF-88 to the MEGA ARCADE parking lot and finish any remaining street enemies. Review Bruce's size beside Buck and Chuck, his walk in both directions, and his feet during idle and walking. The downloadable comparison shows identical emulator frames from the 100% and 85% parking-lot fixtures. The bundled BIN/CUE is the normal gameplay build.

Both fixture runs reached 401,600 resident VDP1 texture bytes and retained the 49,152-byte hero reserve. Movement, targeting and camera traces matched the 100% runs. VDP1 downsampling drops some fine pixels. Physical Saturn review is pending.
