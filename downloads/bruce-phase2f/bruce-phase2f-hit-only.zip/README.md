# Bruce · Approved Phase 2F hit reactions

The approved HIT 00 and HIT 01 PNGs and TGAs match the original delivery
byte for byte. The 144 × 120 canvases, pivot (64, 112), hard masks and
shared idle RGB555 palette are retained. HIT 00 still uses the existing
idle boots. The one-shot plays HIT 00 (100 ms), HIT 01 (150 ms), CHARGE 00
(133 ms), then returns to idle.

The two hit textures use 7,392 and 8,736 bytes, totaling 16,128 aligned
VDP1 bytes. Removing the two dedicated stun textures saves 8,800 bytes.
The bank now contains 15 unique indexed payloads totaling 135,936 bytes.
Remaining headroom under the reserve-safe ceiling is 34,040 bytes.
The 49,152-byte hero reserve is protected.

Regenerate the approved hit exports from the private reference with
`python tools/prepare-bruce-hit.py brucehits.png --output assets/bruce/hit-stun --previews docs/bruce-hit-stun-review`.
