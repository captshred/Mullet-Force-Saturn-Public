# Bruce · Phase 2F hit reactions and stun

Four new 144 × 120 right-facing RGBA poses share the (64, 112) ground
pivot and approved RGB555 palette. Native matte cleanup removed the
impact flashes and stun stars. Gold jewelry and the vest patch remain.
Effects are separate and receive no texture allocation in this phase.

| Pose | Indexed payload | Reused texture regions | New aligned bytes |
| --- | --- | --- | ---: |
| Hit 00 | 96 × 77 | Idle boot view | 7,392 |
| Hit 01 | 104 × 84 | Full recoil with lifted boot | 8,736 |
| Stun 00 | 88 × 77 | Idle boot view | 6,784 |
| Stun 01 | 72 × 28 | Stun 00 body and idle boots | 2,016 |
| **Total** | **4 payloads** | | **24,928** |

The hit plays once at 100, 150 and 133 ms through Hit 00, Hit 01 and
existing Charge 00 recovery. It returns to existing idle. The stun loops
Dazed, Wobble, then Dazed with a one-pixel left offset on its upper
view. Each beat holds 240 ms. Full-body mirroring would change the
facing and reverse the patch. The alternate upper offset keeps the
lower body and soles fixed and costs no extra texture bytes. The
manifest records the views for future runtime integration. The PNGs
are complete, and the two hit/stun composites and head overlay use
existing texture rows at aligned offsets.

The cumulative bank uses **144,736 bytes**, leaving **25,240 bytes**
under the 169,976-byte ceiling while retaining the hero reserve. The
remaining estimates are 12,608 for knockdown, 7,296 for get-up and 5,120
for defeat. That is **25,024 bytes**, leaving 216 bytes of projected
margin. Review the down and defeat settle poses together and consider
reusing the pose if it reads well in both. Sharing that planned
128 × 40 settle would free 5,120 bytes for cleanup or other necessary
pose changes.

Host validation covered exact palette bytes, binary masks, dimensions,
aligned allocation, and preview timing. Runtime staging is deferred.
The source sheet stays private. Reproduce with
`python tools/prepare-bruce-hit-stun.py brucehits.png --output assets/bruce/hit-stun --previews docs/bruce-hit-stun-review`.
