# Bruce Phase 3B.2

Bruce starts at 60 HP, up from 30. A connecting bat deals the existing 3 HP and cancels an active charge or airborne slam before it can deal damage. An interrupted slam stops its ground movement, descends at up to five pixels per simulation tick and finishes the existing hit reaction with the original recovery cooldown.

The published Yabause screenshots use a controlled parking-lot fixture with staged positions and attack timing. It exercised Buck's running bat against the charge and Chuck's bat against the airborne slam. The solo fixture exercised both counters with Buck. Both runs also covered a missed bat, a regular punch that failed to interrupt the charge, unchanged heavy punch and slam damage, and defeat at zero HP. The released Saturn disc uses the normal encounter and controls.

The original 19 textures and 49,152-byte hero reserve remain intact. The emulator measured 401,600 resident VDP1 texture bytes with Bruce loaded.
