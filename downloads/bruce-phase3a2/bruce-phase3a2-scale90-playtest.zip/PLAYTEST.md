# Bruce Phase 3A.2

This playtest uses 90% uniform VDP1 scaling around Bruce's existing ground pivot. The original 19 indexed textures and the protected 49,152-byte hero sprite reserve remain intact.

Play past MF-88 to the MEGA ARCADE parking lot and finish any remaining street enemies. Review Bruce at idle and walking beside Buck and Chuck. The comparison images use matching frames from the Yabause parking-lot fixture at 85%, 90%, and 100%. The ZIP contains the normal gameplay build.
