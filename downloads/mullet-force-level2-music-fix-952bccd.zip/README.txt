Mullet Force Saturn — Level 2 music silence fix

Build commit: 952bccd917dae73f40d0519c80d2d5ee280efb68
Private authoring branch: fix/level2-music-silence
Tested silent predecessor: 7a1de3bda065a3397de764ae5469793405f2aef4

Extract everything together; open mullet-force.cue (MODE1/2048).
This is the complete two-stage game with the existing development X skip.

Root cause: literal 16 in a packed tone header selected unsupported PCM mode
0x10. The real driver rejected every note with error 0x8A before key-on.
Fix: exact working PCM bank with range code 6; native wheel payloads rescaled
from the unchanged 16-semitone source curves. No GP conversion was rerun.
All 4,403 notes, timing, gameplay, SFX and Level 1 content are preserved.

Native build, make check, make test, eight real 68000 control experiments and
256 bend-handler checks passed. CPU tests observe SCSP key-on writes but do
not synthesize audio. Audible Saturn emulator/hardware verification of this
corrected build is still required. The authored first measure is silent.

Read ROOT-CAUSE.md and driver-results.json for exact evidence and limitations.
GP/MIDI/articulation JSON, source bundle and private authoring history are not
in this public ZIP or the public delivery branch.
