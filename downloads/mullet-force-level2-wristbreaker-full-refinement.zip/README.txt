MULLET FORCE — WRISTBREAKER EXPERIMENTAL AUDIO BUILD

Executable source: d97b5a9e77f418d16f22e408690f038f727e1828
Branch: audio/level2-wristbreaker-full-refinement
Protected baseline: the-one-level1-audio-refined-definitive /17445b421bcafd8d5c974d624ddc2a34e768d725

Keep matching BIN/CUE together and load the CUE (MODE1/2048).
Start exits the boot gallery; Start again begins the game. P2 Start joins.
The existing developer Saturn X shortcut skips to Level2; normal progression also works.
Level2 A fires; hold A for the existing focused-fire/Flame behavior.

This build is experimental and awaits owner hardware/listening approval.
All previous definitive tags remain unchanged. No baseline merge is made.

Custom runtime guitar/bass/drums, centered mono rhythm with unique material retained,
complete2803-hit SD3 drum performance, music-only gain and safe loop cleanup.
Level1 assets/code/audio settings, Level2 gameplay/graphics and SFX sample/gain/scheduling remain protected.

Known emulator limitation: the unchanged cached-envelope diagnostic can show SFX LOSS
warnings even though native sample-phase/ownership traces confirm full playback.
The deliberately overloaded scheduler stress also reproduces an inherited same-control
Explosion stop/start edge (8 baseline /12 refined onset-frame scoped offs); normal
controller-driven game/restart captures have full49-frame Explosion endings.
No active cross-owner reassignments, global refined key-offs, lost/reordered music
note-ons, prematurely gated ordinary drum tails or clipped samples were measured.
Extreme native stress peaks31/32 slots; hardware review remains essential.
Read WRISTBREAKER-REFINEMENT.md and HLE-DIAGNOSTIC-EVIDENCE.json for details.

Rebuild exact source:
  git checkout d97b5a9e77f418d16f22e408690f038f727e1828
  bash tools/setup.sh
  bash tools/build-source-complete.sh
  make check
  make test
Host requires the documented native prerequisites including genisoimage.
Public builds need no private GP, MIDI, WAV or sample masters.
Locally built; no GitHub Actions run or actual Saturn hardware validation is claimed.
