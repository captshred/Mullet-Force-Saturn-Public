# Bruce custom SFX playtest

Source commit `70b17960780a40cf9a8a23476b5e70eb307017df` on `feature/bruce-custom-sfx`, based on the Bruce AI candidate `d407bc8f004e80e620ec7b37f2e5df39aa21827f`. THE ONE remains `the-one-performance-phase2-definitive`. This is a physical Saturn playtest candidate.

## Audio cues

| Cue | Trigger | Duration |
|---|---|---:|
| WOOPAH | Once when Bruce raises his arms at the start of the normal slam or anti-stunlock jump. The entry ditty and its trigger are unchanged. | 1.214 s |
| Charge | Once at commitment to the charge windup. | 0.735 s |
| Arghhh | An accepted nonlethal bat, air kick or combo cross from either player. The same recording is used at higher priority when Bruce dies, including a lethal torch tick. | 0.598 s |
| Laugh | One crossing from above 15 HP to 15 HP or less in the 75 HP encounter. Death takes priority if a hit crosses the threshold and kills Bruce. | 0.888 s |

The archive's exact death filename is `Arghhh.wav`. The cues play on driver control 7 during the encounter and layer over music, hits, impacts, jump and flame. The normal protected POOWAH path uses the same control on the street. The handoff waits for a protected street POOWAH to finish, and new POOWAH requests are blocked throughout Bruce's encounter. Bruce's death plays only his own death voice. The sequencer accepts one Bruce voice at a time. Death can interrupt it. WOOPAH stays continuous through ordinary overlaps. The laugh can wait behind an already playing cue and gives way to attack warnings. Lower-priority reactions coalesce during overlaps, and an attack request that cannot start within four fields expires to avoid a stale warning.

## WOOPAH timing at 60 Hz

```
0.00 s          0.30–0.33 s      ≈0.58–0.60 s      0.77–0.83 s       1.21 s
Arms rise  ───► Takeoff     ───► Estimated PAH ───► Landing     ───► Cue ends
Cue starts
```

The estimate comes from the waveform envelope. The PAH begins roughly 0.17–0.25 seconds before unpaused touchdown at the approved simulation timing. The entire recording stays in one sample. PCM conversion preserves duration and pitch to the driver's nearest chosen playback rate, with no splitting, trimming, time stretch, or animation retiming. Existing hit-stop can move the visible landing later relative to wall-clock audio.

## Sound RAM

The source WAVs are 44.1 kHz stereo unsigned PCM8. The banks use 7,796 Hz mono signed PCM8, selected to match the 30-semitone SCSP pitch step from the native rate. These sizes exclude each program's alignment and guard bytes.

| Cue | Source frames | Converted PCM bytes |
|---|---:|---:|
| WOOPAH | 53,540 | 9,465 |
| Charge | 32,409 | 5,730 |
| Arghhh | 26,368 | 4,662 |
| Laugh | 39,139 | 6,919 |

| SCSP phase | Used or reserved | Free |
|---|---:|---:|
| Bruce AI parent, vehicle bank loaded | 508,668 B | 15,620 B |
| New build, vehicle payload and Bruce sequence loaded | 508,836 B | 15,452 B physically unoccupied |
| New build, largest mapped footprint and Bruce bank loaded | 517,300 B | 6,988 B |

The Bruce tone bank is 27,004 bytes and the sequence bank is 168 bytes. The tone bank takes the vehicle bank's slot after the ambush, at the existing Bruce sprite-bank boundary, and the vehicle bank is restored on backtrack. Slot reuse waits for the prior voice and release guard. The high work RAM link end moves from `0x060b4f24` to `0x060b5744`, leaving 43,196 bytes before the SGL sort-work boundary `0x060c0000`. The expanded tile dictionary and graphics memory allocations are unchanged.

## Test evidence

The native build, `make check`, and `make test` passed. Native fixtures exercise accepted bat reactions for both characters, threshold crossing, lethal precedence, one-shot windups, PCM retirement, reversible bank ownership, and protected POOWAH exclusion during Bruce. The final disc's 433 existing non-executable files match the Bruce AI candidate byte for byte. The only added ISO files are the two runtime banks under `RICKY`.

The included Yabause traces read the SCSP slot address and envelope state while driving the game through controller inputs. The co-op fight produced eight full WOOPAH plays and five charges. Six accepted reactions and one distinct death event played Arghhh. The laugh played once and yielded to the next WOOPAH after 48 observed fields. Bruce voices overlapped the existing FX bank for 866 fields. POOWAH played on the street for 45 fields and was absent during the encounter. The fight introduced no missed callback opportunities after the entrance loaded. Both solo and co-op runs defeated Bruce and drew Level 2 using the existing Saturn X dev skip two seconds after defeat. The solo fight also played all four cues, recorded zero steady-fight misses, and showed no POOWAH slot during the fight. The reverse run restored vehicle bank ownership without an audio load fault.

The emulator attributed 53 missed callback opportunities to the combined Bruce entrance transition and 119 to the return transition. The equivalent controller route on the Bruce AI parent recorded 46 and 116 respectively. These intervals include the existing sprite-bank load and the extra audio bank read. Physical audio quality, voice contention and loading time remain to be checked on Saturn.

To playtest, open `mullet-force.cue` with the BIN beside it. Listen for Bruce's voice on top of impact and flame audio. Verify the full jump cue, the one-time laugh around 15 HP, and Arghhh on defeat. Ordinary enemies outside the encounter should retain POOWAH. Backtrack out of the arcade lot to test the reverse bank transition. Press P1 Y to show MISS, and record the entrance and backtrack transitions separately from steady combat.
