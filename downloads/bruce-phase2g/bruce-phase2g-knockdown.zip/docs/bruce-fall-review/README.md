# Bruce Phase 2G native sprite review

The four new right-facing poses use 144 × 120 RGBA canvases and share the (64, 112) ground pivot. KD 01 uses a (−4, −9) render offset for the airborne beat. The previews decode the indexed textures at 1×. Knockdown and defeat end on KD 02, and get-up starts on that same texture. The get-up recovery uses CHARGE 00 with its existing shared idle boot view. The existing idle manifest defines the full idle loop.

| Pose | Texture | VDP1 bytes |
| --- | --- | ---: |
| Knockback | BF00.TGA | 6,496 |
| Falling | BF01.TGA | 7,552 |
| Face-down | BF02.TGA | 5,920 |
| Kneeling recovery | BF03.TGA | 6,336 |
| Fighting stance recovery | Existing CHARGE 00 | 0 |
| Phase 2G total | Four unique textures | 26,304 |

The full Bruce bank has 19 unique textures and uses 162,240 of 169,976 reserve-safe bytes. That leaves 7,736 bytes and preserves the 49,152-byte hero reserve. The export checks the approved palette, hard-alpha mask parity, padded widths, anchors, mirroring, unique texture IDs and aligned allocations.

The preview timings are for art review. Knockdown holds the face-down pose until get-up and defeat holds it until the encounter transition. The private HQ reference stays in the authoring workflow. Runtime integration and hardware validation follow visual approval.
