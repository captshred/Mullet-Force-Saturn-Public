# Bruce · Phase 2C heavy punch review

The loop reference on the source sheet is treated as a one-shot per the
Phase 2C brief. Three right-facing 144 × 120 PNGs share ground pivot
(64, 112). The native poses are 93–95 pixels tall. The extended pose spans
127 pixels. Matte cleanup removes the source lettering and background.
There are no impact effects baked into the frames.

| Pose | Saturn texture | Anchor | Preview hold | Aligned VDP1 bytes |
| --- | --- | --- | ---: | ---: |
| 00 · windup | BP00.TGA, 104 × 80 | (50, 95) | 240 ms | 8,320 |
| 01 · forward twist | BP01.TGA, 104 × 80 | (52, 95) | 140 ms | 8,320 |
| 02 · full extension | BP02.TGA, 128 × 93 | (55, 93) | 160 ms | 11,904 |
| Recovery | Existing neutral idle | Existing idle anchor | 480 ms | 0 |

The first two PNGs include complete character art. Their indexed TGAs
contain the upper part and refer to the same existing 104 × 15 boot view
of BR00.TGA at aligned decoded offset 8,320, anchor (53, 15). A future
runtime can register one shared row-view definition and submit it under
the upper body. The extension retains its independently drawn lunge.
The manifest's texture counts exclude the extra row-view definition,
which would reuse the idle allocation with no incremental texture bytes.

Idle and walk use 50,112 bytes. Punch adds 28,544 aligned bytes, bringing
the bank to 78,656 and leaving 91,320 bytes below the 169,976-byte
reserve-safe ceiling. All textures share the same approved idle palette
bytes. Host checks verified indexed round-trips, no opaque raw index 255,
and exact opacity agreement with all complete production PNGs. Runtime
staging and draw verification are deferred until after art approval.

Reproduce from the private approved source with
`python tools/prepare-bruce-punch.py brucepunch.png --output assets/bruce/punch --previews docs/bruce-punch-review`.
