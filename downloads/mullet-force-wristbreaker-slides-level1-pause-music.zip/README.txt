MULLET FORCE — SLIDE / PAUSE EXPERIMENTAL PLAYTEST
Executable source: 38ed9a690f9349f490b5280992fcef882b32aaaf
Branch: fix/wristbreaker-slides-level1-pause-music
Approved starting executable: d97b5a9e77f418d16f22e408690f038f727e1828

Keep matching BIN/CUE together; load the CUE (MODE1/2048).
Start exits gallery; Start again begins. P2 Start joins. P1 Start pauses.
The existing Saturn X developer shortcut reaches Level2; normal progression remains unchanged.

Wristbreaker: retained72.8ms initial hold, then145.6ms slide movement.
102 chord onsets /203 note trajectories corrected; low-string attacks unchanged.
Level1: music keeps playing while gameplay and new gameplay SFX remain paused.

IMPORTANT: E108 is a pre-existing intermittent Level2 startup issue, confirmed
by the owner and intentionally deferred. It was observed in baseline and candidate
late-handoff captures; other post-pause handoffs succeeded. Reload/restart may
be needed. E108 is NOT fixed and not all cold-start/handoff attempts pass.
No startup or stage-transition source was changed. Existing baseline HLE cached
SFX warnings /extreme-overload SFX retrigger limitation are also unchanged.

Native build, make check, make test, source fidelity and cold source-checkout
validation passed. Native pause:5375 music note-ons,0 new SFX ons, complete loop;
13900 unchanged world frames. Level2 stress31/32 slots;0 clipped samples.
Final-source6000-frame pause/transition audio is bit-identical to the tested candidate.
These are emulator/model results. Owner hardware/listening approval is pending.
No new definitive tag or merge. All existing THE ONE tags remain protected.

Rebuild: bash tools/setup.sh; bash tools/build-source-complete.sh; make check; make test
GitHub Actions: workflow from main, profile stage-default, source_ref 38ed9a690f9349f490b5280992fcef882b32aaaf
This ZIP was built locally; no Actions run is claimed. No private GP/MIDI/WAV masters included.
