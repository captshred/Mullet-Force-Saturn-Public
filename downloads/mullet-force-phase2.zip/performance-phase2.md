# Mullet Force Phase 2 background streaming

Phase 2 eliminated ordinary gameplay pacing gaps in the 5,200-field Yabause controller replay. The longest ordinary callback fell from **149.36 ms to 3.96 ms**. The Bruce bank install still caused one gap. Phase 2 timings on a physical Saturn are pending.

The build comes from branch `performance-phase2`, source commit `758cca4bcb314608d0f5eac26b28b6be5e14769a`, based on THE ONE `9ab6f908f6b736bea924fe223050be1a6c32b712`. Phase 1 instrumentation came from `85788c90d4d7e0d6ece8612dd2c39be71d5d0e18`. THE ONE remains the approved baseline. [Phase 1 report](performance-audit.md)

## Hardware observations from Phase 1

On the user's Saturn, stationary combat and backtracking through the first transition added no misses. Forward travel through new scenery raised MISS near ION ARCADE, then to about 92 at LAST CALL LIQUORS, 300 downhill and 350 after the ambush. New misses stopped when movement stopped. The reported coincidence with a trash can has not been isolated as a cause. These observations confirm the travel-dependent pacing symptom on hardware. MISS counts opportunities between callback starts. It does not directly count captured video frames or time VDP1 draw completion.

## What caused the spikes

The previous prefetch limit applied only to speculative decoding. A missing pattern on the new ring edge still called the Huffman/LZ decoder synchronously. Adjacent visual tiles could refer to different blocks and need those blocks in the same callback. Each cache miss also searched 128 entries and copied 512 bytes into the cache. Cache hits could copy an entire block back to scratch before uploading a 64-byte tile.

For every edge change the renderer cleared the pin bitset, walked both ring windows, traversed the full new ring to find changed entries, and rebuilt the sixteen-column prefetch queue. These repeated scans mattered even when very few VDP2 name-table words changed. The profile below separately measures the decoder, cache lookups and victim search, cache copies and residency bookkeeping, ring marking, prefetch queue work, pattern stores, and name-table stores. Traversal between those probes and instrumentation overhead remain in the total.

## Implementation

- The boot loader uses the approved compressed files and the same decoder, while the display is off. It expands all 1,282 blocks in place in descending order and retains the exact indexed tiles. It validates the packed offset against the output boundary before each copy and decodes through scratch so a block's output can overlap its own input. CD reads still stage through the original high work RAM buffer. Gameplay takes tiles from the expanded dictionary without invoking the decoder, making a cache miss a fixed 64-byte pattern upload plus residency bookkeeping.
- The renderer updates entering and leaving columns and rows. Per-source reference counts protect every tile in the current guard ring and the retiring edge of the prior ring until the next callback. Ring changes update only the nonoverlapping strips, including a corner shared by horizontal and vertical movement. Large discontinuities retain the approved full-ring rebuild behavior.
- The predictor looks eight pixels ahead in the current direction and walks the approaching column and any approaching slope row. It considers at most 48 candidates and uploads at most eight missing patterns per callback. It reuses its cursor across callbacks, skips resident patterns, resets on reversal and can leave any unfinished tile to the fixed-size demand path. Speculative uploads use the existing cache and do not alter the name table. No new graphics transfers occur when the nearby edge is already prepared.
- Approved palette indices, transparent pixels, road geometry, scrolling, simulation, animation, audio, vehicle and Bruce behavior are unchanged by the optimization. The diff changes the Level 1 background renderer, diagnostics and validation. The Level 2 handoff still releases the Level 1 heap and clears the tile pointer before starting its loader.

## Same-input Yabause results

Each column uses the same 5,200 emulated fields and `walk` input schedule on libretro Yabause `8926b0c6c347f8c5c755911ddb0ac695420ffbf8`, with HLE BIOS, interpreter, 60 Hz output and one rendering thread. The overlay was hidden during timing. Phase 1 is the original distributed diagnostic. The second column replays the old renderer with the added per-operation probes at commit `959adc4`, because Phase 1 did not time all requested operations. Extra instrumentation perturbs pacing near field boundaries, so its overall pacing totals differ from the original.

Counts use the next callback's VBlank gap for attribution and exclude startup and menus. Ordinary gameplay excludes the synchronous bank-install callback. Times are emulated SH-2 elapsed times, converted with the same clock estimate across all runs.

| Metric | Phase 1 diagnostic | Old renderer, detailed probes | Phase 2 |
|---|---:|---:|---:|
| Gameplay pacing gaps | 227 | 259 | 1 |
| Gameplay missed opportunities | 304 | 338 | 46 |
| Ordinary pacing gaps / missed opportunities | 226 / 259 | 258 / 293 | **0 / 0** |
| Ordinary CPU median / maximum | 2.12 / 149.36 ms | 2.11 / 106.02 ms | 2.16 / **3.96 ms** |
| All gameplay CPU maximum, including Bruce install | 754.34 ms | 754.44 ms | 768.82 ms |
| Peak streaming | 147.05 ms | 103.87 ms | **1.80 ms** |
| Peak decompression / blocks in one callback | 128.57 ms / 30 | 86.75 ms / 21 | **0 ms / 0** |
| Peak streaming outside decoder and pattern stores | 17.93 ms | 17.43 ms | **1.34 ms** |
| Peak lookup and victim search | — | 1.32 ms | 0.11 ms |
| Peak cache copies and residency bookkeeping | — | 4.75 ms | 0.06 ms |
| Peak ring marking | — | 7.59 ms | 0.22 ms |
| Peak prefetch scan or queue construction | — | 1.79 ms | 0.22 ms |
| Peak VDP2 pattern stores | 0.73 ms | 0.69 ms | 0.46 ms |
| Peak name-table stores | — | 0.10 ms | 0.10 ms |
| Pattern bytes, total / peak callback | 548,928 / 2,432 | 548,928 / 2,432 | 549,056 / 1,792 |
| Name-table bytes, total / peak callback | 24,074 / 86 | 24,074 / 86 | 24,074 / 86 |
| VDP1 gameplay draw lists / primitives | 3,993 / 107,916 | 3,993 / 107,599 | 3,993 / 111,182 |
| Peak VDP1 primitives per gameplay field | 44 | 44 | 44 |

All three runs reached camera X 2880, exercised three street enemy slots, vehicle, torches and Bruce. Phase 2 produced more gameplay callbacks and the same number of per-field VDP1 draw lists. With wall-field input held identical, removing stalls changes the tick at which a held or pressed input is sampled. Combat poses, effects and same-field image hashes can therefore differ across runs. The cache test verifies background pixels at equal camera positions, and the native gameplay and renderer regressions verify their respective behavior. Yabause's synchronous VDP1 completion gives no measure of real raster headroom.

The separate reverse pass turned at camera X 1831, returned to X 1545, and proceeded forward to X 2880. It added zero misses during the reversal and traversal and never installed Bruce in that pass. The overlay A/B replay verified the two P1 Y toggles. The dev-skip handoff replay stopped Level 1 telemetry and resumed continuous draw lists after the existing Level 2 load. No timer faults occurred in the main replay. The first instrumented callback arrived at emulated field 993, versus 982 in Phase 1, an 11-field increase in cold-start time. The main replay uploaded two additional patterns overall while reducing the peak upload size.

## Memory and validation

| Resource | Phase 1 | Phase 2 |
|---|---:|---:|
| Low work RAM, background source | 437,304 B packed | 656,384 B expanded, including last-block padding |
| Retained high work RAM background heap | 112,765 B | 62,440 B |
| Temporary CD staging request | 65,540 B | 65,540 B |
| Linked high work RAM end | `0x060b5534` | `0x060b4cc4` |
| Background VDP2 pattern slots and bytes | 1,664 / 106,496 B | 1,664 / 106,496 B |
| VDP1, VDP2 and SCSP reservation deltas | — | 0 B |

The expanded source occupies `0x0025fc00–0x002fffff`. This extends the prior upper-half reservation downward by 132,096 bytes and leaves 392,192 bytes below it in the 1 MiB low work RAM. The project and pinned engine link game data, stacks and SDK work areas in high work RAM. The runtime continues to check the background heap against `0x060c0000`. The expanded data is never used as a CD DMA destination. The emulator exercised boot, the full traversal, Bruce and Level 2 handoff with the new range. Physical testing still needs to confirm boot and traversal on the user's Saturn and loading medium.

The Saturn native build, `make check`, and `make test` passed. All 433 non-executable ISO files match the Phase 1 disc byte for byte. The native cache regression, built with UBSan, checks every camera pixel in both directions, both guard rings during adjacent changes, the full exact tile decode, VRAM sentinels, cold resets, sub-tile reversals and malformed streams. The bundle contains the full logs and replay CSVs.

## Physical Saturn playtest

Keep BIN and CUE together and load `mullet-force.cue`. Use the same console, controllers and disc loader as the Phase 1 run. Start gameplay, press **P1 Y** once, and note the starting **MISS**. The overlay refreshes about twice per second and shows **CAMERA** X, so stop briefly at each checkpoint to capture the reading. Compare the **change** in MISS since the previous point. Cold boot and gallery exit can add opportunities before gameplay.

| Checkpoint | What to capture |
|---|---|
| Stationary co-op combat | Start and end MISS over 20 seconds, with enemies, attacks and both torches if possible |
| First transition near ION ARCADE | MISS and CAMERA before entering and after passing the transition |
| Backtrack through ION ARCADE | MISS before turning, after returning and when crossing forward again |
| LAST CALL LIQUORS | MISS and CAMERA at the storefront, then after moving into the intersection |
| Downhill | MISS at the first downhill motion and again just before the ambush. The camera begins dropping just after X 1600. |
| End of the vehicle ambush | MISS when the vehicle clears and again once the camera resumes following. Note any visual corruption or pop-in. |

Also test a short reversal on the slope before the ambush if the route permits. Record the disc loader, console region, any **TIMER** fault, and the biggest **MAP** or **CPU** peak visible around a missed opportunity. Stop the Phase 2 comparison before the Bruce bank swap. Its separate loading stall is expected. A rising MISS with low CPU/MAP peaks would justify testing synchronization and graphics timing on hardware before changing the renderer again.

## Reproduce

```sh
bash tools/setup.sh
MF_PERFORMANCE_AUDIT=1 bash tools/build-stage.sh --native
make check
make test
bash tools/run-performance-audit-emulator.sh 5200 walk build/performance-phase2.csv
bash tools/run-performance-audit-emulator.sh 5200 reverse build/performance-reverse.csv
bash tools/run-performance-audit-emulator.sh 1650 overlay build/performance-overlay.csv
bash tools/run-performance-audit-emulator.sh 3000 handoff build/performance-handoff.csv
```

Use a new nonzero `sequence` with `publishing=0` for each completed callback. A `gap` of two on the following callback contributes one missed opportunity. The CSV draw-list and primitive counts are per emulator field, including fields that repeat the last callback record. The detailed legacy profile is reproducible with the same native build and `walk` command at commit `959adc4`. The original Phase 1 trace is bundled separately.
