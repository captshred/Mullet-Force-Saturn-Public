# Bruce Phase 3B.1 ground-slam lunge

Approach the MEGA ARCADE lot after clearing the downhill ambush and any remaining street enemies. When Bruce raises both fists, move along the floor or time a jump to avoid the landing.

The windup lasts 18 simulation ticks. Bruce commits to the nearest living player's position at the start of that windup. He then travels in a 32-tick arc with a 44-pixel apex and deals the original 24 HP only at touchdown. The published Yabause captures use the production combat and rendering code with fixture placement to exercise left and right launches. The disc in this ZIP uses the normal stage traversal.

The solo fixture measured (2908.875, 203.75) to (2798, 222). Buck moved after launch and kept his 58 HP. The co-op fixture measured (2911.125, 203.75) to (3018, 222). Bruce committed to Chuck, Buck jumped clear, and Chuck took one 24 HP hit at landing. Coordinates are world X and ground-lane Y. Both captures reached a 44-pixel visual apex and 401,600 resident VDP1 texture bytes.
